## PHP example Project ##

### `-------Rajshahi University Online Notice Board---` ###

### Installation ###
* `git clone https://github.com/Jaggesher/Rajshahi_University_Online_Notice.git`
* `Coppy It to C:\xampp\htdocs`
* `Create Database Named 'notice'`
* `Copy And Execute All SQL Command on Basic.sql`
* `ENJOY`

To test application the database:
* ADMIN : ID= 14015439, password = 14015439
* or ADMIN : ID = 14025423, password = 14025423
* UPLOADER : ID = 14035440, password = 14035440
