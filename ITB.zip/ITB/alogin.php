


<?php



$dbc = mysqli_connect('localhost', 'root', 'root', 'trial') or die('Error connecting to MySQL server.');

$username = $_POST['username'];
$password = $_POST['password'];
$query = "SELECT * from admin where username='$username'";
$result = mysqli_query($dbc, $query) or die ('Error querying database.');
$row = mysqli_fetch_array($result);


if($row['username'] == $username && $row['password'] == $password)
    header('location: admin_notice.php');
    else {
    echo "Error u have entered a wrong username or password"."<br>";  
    }

echo "<br />";




mysqli_close($dbc); 
?>
    