<html>
<head>
    <style>
        table {
    margin: auto;
    width: 50%;
    border: 3px solid green;
    padding: 10px;
}
        
        table, th, td {
   border: none;
}
        td {
            padding: 8px;
            text-align: center;
        }
        
        table {
            border-collapse: collapse;
            align-self: center;
        }
        
        tr:hover {background-color: #f5f5f5;}
    </style>

<?php

$dbc = mysqli_connect('localhost', 'root', 'root', 'trial') or die('Error connecting to MySQL server.');

$branches = [
    'mec',
    'cse',
    'ece',
    'pet',
    'eee',
    'civ'
];
$noticeLists = [];
// foreach ($branches as $branch) {
    $query = "SELECT * from notices where branch='$branch'";
    $result = mysqli_query($dbc, $query) or die ('Error querying database.');
    $rows = mysqli_fetch_all($result);
    $noticeLists[$branch] = $rows;
// }

foreach ($noticeLists as $branch => $noticeList) {
    echo <<<MULTI_LINE_STRING
<div style="display: block;">
    <h3 style="background: #fafafa; padding: 8px; margin-bottom: 0px;">$branch</h3>
    <table style="margin-top: 0px;">
    <tr>
    <th>Notice</th>
    </tr>
    
    
MULTI_LINE_STRING;
    foreach ($noticeList as $notice) {
        $noticePath = $notice[2];
        $noticeId = $notice[0];
        $noticeTitle = $notice[1];
        echo <<<MULTI_LINE_STRING
        <tr>
        <td><a href="uploads/$noticePath">$noticeTitle</a></td>
        </tr>
MULTI_LINE_STRING;
    }
    
    echo <<<MULTI_LINE_STRING
    </table>
</div>
MULTI_LINE_STRING;
}

mysqli_close($dbc); 


?>