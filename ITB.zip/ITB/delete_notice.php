<?php

$dbc = mysqli_connect('localhost', 'root', 'root', 'trial') or die('Error connecting to MySQL server.');

$id = $_GET['id'];
$query = "DELETE FROM notices WHERE id='$id'";
mysqli_query($dbc, $query);
echo 'Notice was deleted successfully.';

mysqli_close($dbc); 

?>