$(document).ready(
    function() {
        var password =  $(document).find("#password").val();
        var username = $(document).find("username").val();
        var submit = $(document).find("submit");
        var successful = false;
        submit.submit(function(event) {
            $(document).post(
                'login.php?check=true',
                {
                    'username' : username,
                    'password' : password
                },
                function (PlainObject data, String textStatus, jqXHR jqXHR) {
                    if (textStatus == 'ok') {
                        successful = true;
                        submit.click();
                    }
                }
            );
            if (!successful) {
                event.preventDefault();
            }
        }
    }
);